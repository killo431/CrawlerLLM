/*
 * ERROR FETCHING RESOURCE
 * -------------------------
 * URL: https://d3niuqph2rteir.cloudfront.net/client_js/stellar.js?apiKey=c86dcfb65d60419be4a792a8bfff4788:c2433cc5b5eab0e8abc1b95556d12cf4c728b6343b52ec8130bd52408eaca98b
 * Type: JS
 * Error: Failed to fetch
 */