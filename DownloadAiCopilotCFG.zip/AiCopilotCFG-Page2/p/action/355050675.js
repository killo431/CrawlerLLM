/*
 * ERROR FETCHING RESOURCE
 * -------------------------
 * URL: https://bat.bing.com/p/action/355050675.js
 * Type: JS
 * Error: Failed to fetch
 */