/*
 * ERROR FETCHING RESOURCE
 * -------------------------
 * URL: https://bat.bing.com/bat.js
 * Type: JS
 * Error: Failed to fetch
 */