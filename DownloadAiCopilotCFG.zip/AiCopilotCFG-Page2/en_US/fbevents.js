/*
 * ERROR FETCHING RESOURCE
 * -------------------------
 * URL: https://connect.facebook.net/en_US/fbevents.js
 * Type: JS
 * Error: Failed to fetch
 */